# PivotViewDefinitionColumnDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**column_type** | **str** | The column type. | [optional] 
**name** | **str** | Name of the pivot view column. The maximum size is 255 characters. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


