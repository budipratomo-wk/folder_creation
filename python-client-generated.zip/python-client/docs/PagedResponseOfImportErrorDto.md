# PagedResponseOfImportErrorDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**list[ImportErrorDto]**](ImportErrorDto.md) |  | [optional] 
**code** | **int** |  | [optional] 
**cursor** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


