# QueryDependencyDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**database_id** | **str** | The database in which this dependency exists. | [optional] 
**system** | **str** | The name of the system holding this reference. | [optional] 
**table_id** | **str** | The id of the table this dependency represents. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


