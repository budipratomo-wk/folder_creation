# URL

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authority** | **str** |  | [optional] 
**content** | **object** |  | [optional] 
**default_port** | **int** |  | [optional] 
**file** | **str** |  | [optional] 
**host** | **str** |  | [optional] 
**path** | **str** |  | [optional] 
**port** | **int** |  | [optional] 
**protocol** | **str** |  | [optional] 
**query** | **str** |  | [optional] 
**ref** | **str** |  | [optional] 
**user_info** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


