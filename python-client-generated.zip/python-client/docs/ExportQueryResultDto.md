# ExportQueryResultDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | URL of the spreadsheet to export to, if present. If not present, a new spreadsheet will be created. | [optional] 
**use_flat_key** | **bool** | Export flat query results in the context of crosstab queries; Ignored unless true. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


