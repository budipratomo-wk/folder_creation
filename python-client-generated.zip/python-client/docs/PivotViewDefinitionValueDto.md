# PivotViewDefinitionValueDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **bool** |  | 
**aggregation** | **str** | The aggregation type to apply to the pivot view value | 
**column_type** | **str** | The column type. | [optional] 
**name** | **str** | Name of the pivot view value. The maximum size is 255 characters. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


