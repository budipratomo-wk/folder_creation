# QueryTextDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query_text** | **str** | queryText to be parsed, if present and valid. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


