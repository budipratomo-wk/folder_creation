# DatetimeDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**candidate** | **str** | Candidate to parse with the provided dateformat. | 
**date_format** | **str** | The dateformat of the candidate to test. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


