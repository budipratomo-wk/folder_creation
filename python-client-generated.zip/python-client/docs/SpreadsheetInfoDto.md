# SpreadsheetInfoDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sheet_id** | **str** | The unique identifier of the sheet | [optional] 
**workbook_id** | **str** | The unique identifier of the workbook | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


